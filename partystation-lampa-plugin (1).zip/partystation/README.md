# SDL² PARTYstation для Lampa

Плагин добавляет отдельный пункт **PARTYstation** в меню Lampa и показывает каталог игр с `pstv.ru` в удобном ТВ-интерфейсе.

## Быстрая установка

Добавьте в загрузчик плагинов Lampa/Lampac:

```js
'https://sdlampac.fun/plugins/partystation.share.js'
```

Если ставите локально — скопируйте `partystation.js` в папку `wwwroot/plugins/` и добавьте:

```js
'{localhost}/plugins/partystation.js'
```

## Что умеет

- отдельная кнопка **PARTYstation** в главном меню Lampa;
- каталог игр PARTYstation;
- категории;
- поиск;
- избранное;
- фильтр бесплатных игр;
- отметки доступа на карточках:
  - `FREE`
  - `Доступно`
  - `Golden`
  - `Нужен вход`
  - `Нужна подписка`
- раздел **Аккаунт**:
  - вход по телефону через официальный код PSTV;
  - вход по email через официальный код PSTV;
  - отображение профиля;
  - статус подписки;
  - Golden Ticket;
  - промокоды;
  - активация промокода;
  - выход из аккаунта.

## Как запускаются игры

Каталог и аккаунтный экран сделаны в плагине, но сами игры запускаются через официальный PSTV TV runtime.

По умолчанию используется wrapper:

```js
https://sdlampac.fun/gamehub/pstv.html?target=
```

Если хотите использовать свой wrapper, задайте до загрузки плагина:

```js
window.SDL2_PSTV_WRAPPER = 'https://your-host/gamehub/pstv.html?target=';
```

Файл wrapper’а есть в архиве: `pstv-wrapper.html`.
Его можно положить как:

```text
wwwroot/gamehub/pstv.html
```

## Безопасность

- Пароли не сохраняются.
- Вход идёт через официальный код PARTYstation.
- PSTV-токен хранится только локально в Lampa storage:

```text
sdl2_pstv_auth_token_v1
```

- В архиве нет личных токенов, аккаунтов или привязки к конкретному пользователю.
- Финальная проверка доступа к игре всё равно остаётся на стороне официального PSTV runtime.

## Файлы

- `partystation.js` — сам плагин;
- `pstv-wrapper.html` — fullscreen-wrapper для запуска PSTV TV runtime;
- `README.md` — эта инструкция;
- `SHA256SUMS` — контрольные суммы.

## Публичные ссылки

Плагин:

```text
https://sdlampac.fun/plugins/partystation.share.js
```

Архив:

```text
https://sdlampac.fun/plugins/partystation-lampa-plugin.zip
```
